Hello Font Lovers!

This font is for personal use only

Visit my portfolio on Behance:
https://www.behance.net/candacp

if u want to DONATE click here https://www.paypal.me/ippisuradin
we really appreciate your donations.

visit my shop on Graphicriver 
https://graphicriver.net/user/candacreative

visit my shop on Creative Fabrica
https://www.creativefabrica.com/designer/candacreative


Thank you so much!
CANDA CREATIVE STUDIO